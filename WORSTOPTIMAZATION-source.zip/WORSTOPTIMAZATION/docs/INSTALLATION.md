# Installation

1. Install Minecraft Java Edition **1.21.11** and a compatible Fabric Loader profile. Java 21 is required.
2. Start that profile once, then close Minecraft.
3. Download the compiled `worstoptimazation-1.0.0.jar` from the project's successful GitHub Actions artifact (or build it locally as described in `BUILD_GUIDE.md`). Do not use the source ZIP as a mod.
4. Copy the JAR into that Minecraft instance's `mods` folder. Keep a compatible Fabric API JAR in the same folder.
5. Sodium and BadOptimizations are optional; use only builds explicitly marked compatible with Minecraft 1.21.11. They are not bundled with this project.
6. Start the Fabric profile. Press **O** to open settings, or **F8** to toggle the FPS overlay.

## Android launchers

For PojavLauncher, MJ Launcher, or Zalith Launcher, open the specific Minecraft 1.21.11 Fabric instance's file manager and find that instance's `mods` folder. Folder paths differ across launchers and Android versions; do not copy the file into a different instance's folder. Use an instance that already launches Fabric 1.21.11 successfully.

## PC

Open the Minecraft game directory for the exact Fabric profile and place the JAR in `.minecraft/mods` (or the instance-specific mods folder used by your launcher).
