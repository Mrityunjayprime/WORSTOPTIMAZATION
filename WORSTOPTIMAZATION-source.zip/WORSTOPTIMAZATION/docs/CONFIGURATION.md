# Configuration

File: `.minecraft/config/worstoptimazation.json` (or the profile/instance's equivalent config directory).

Settings include FPS overlay visibility, displayed statistics, one of four HUD corner anchors, scale, chosen profile, and a schema version. Values are validated on load. If JSON is malformed, the file is preserved under a timestamped `worstoptimazation.corrupt-*.json` name when possible, then safe defaults are recreated. Existing valid configuration gets a `.bak` backup when saved.

Quick Optimize saves a snapshot of the current mod configuration plus vanilla render distance, simulation distance, and particle mode to `worstoptimazation-previous-settings.json`. Use **Restore Previous** to apply it. Restore-point creation must succeed before a preset is applied.
