# Compatibility

- Target: Minecraft Java Edition 1.21.11, Fabric, Java 21.
- Mappings: Mojang official mappings through Fabric Loom.
- Fabric API is a required runtime dependency.
- Sodium (`sodium`) and BadOptimizations (`badoptimizations`) are optional and detected by their Fabric mod IDs. Their versions are read from installed mod metadata when available. This project does not bundle, copy, or call their private APIs.
- No Mixin is used in 1.0.0. This intentionally avoids unvalidated injection targets and conflicts with Sodium's renderer.

## Honest limits

The 1.0.0 feature set changes only video settings exposed through Minecraft's public options: render distance, simulation distance, and the global particle quality. It does not claim granular control over weather/potion/block particle categories, per-texture animations, entity culling, chunk scheduling, CPU/GPU usage, temperature, or physical RAM. Individual texture-animation toggles and a new render pipeline are omitted until they can be implemented and tested against this exact Minecraft version and resource-pack/Sodium combinations.
