# Performance testing

No performance benchmark is claimed for this source snapshot. Actual improvement depends on the scene, CPU/GPU, drivers, resolution, shader/resource packs, render distance, other mods, and thermal conditions.

For a useful comparison:

1. Use the same world/seed, location, camera direction, display resolution, render and simulation distances, resource pack, and mod set.
2. Let the scene settle for 30 seconds after loading.
3. Measure at least 60 seconds with the same route and camera movement. Record median FPS, 1% low FPS, average frame time, and frame-time spikes from the same tool.
4. Repeat three times before and after a profile change, alternating test order when possible.
5. Record JVM heap allocation separately from total physical memory. The overlay shows JVM heap usage only.

The overlay computes FPS from actual HUD-frame timestamps. It does not estimate GPU load or CPU temperature. A blank/unavailable statistic is preferable to a fabricated value.
