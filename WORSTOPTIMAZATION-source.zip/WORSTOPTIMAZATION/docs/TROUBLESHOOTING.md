# Troubleshooting

- **Mod does not load:** confirm Minecraft 1.21.11, Java 21, Fabric Loader, and Fabric API compatibility; inspect `logs/latest.log`.
- **Wrong profile:** ensure the JAR is in the `mods` folder belonging to the Fabric instance actually launched.
- **Overlay hidden:** press F8 or open the settings with O; vanilla's F1 hide-GUI option also hides ordinary HUD elements.
- **No individual animation toggles:** that control is deliberately not implemented in 1.0.0 rather than presenting ineffective switches.
- **Preset restore unavailable:** restore becomes active after a preset has successfully written a restore point.
- **Config recovery:** inspect the timestamped `.corrupt-*.json` copy before deleting it; defaults are used after malformed JSON.
- **Report a crash:** attach the relevant `latest.log` and crash report, Minecraft version, Java version, Fabric Loader/API versions, and the exact mod list. Review files for private server addresses or usernames before sharing.
