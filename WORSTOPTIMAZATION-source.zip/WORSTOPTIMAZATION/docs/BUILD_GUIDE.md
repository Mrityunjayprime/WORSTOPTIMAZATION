# Build guide

## Requirements

- 64-bit Java Development Kit 21
- Internet access to the official Maven repositories on the first build
- Gradle 9.4.x (the included `gradlew` / `gradlew.bat` bootstrap scripts download the pinned Gradle distribution when needed; the official binary `gradle-wrapper.jar` could not be downloaded in the offline authoring environment)

## Build

Linux/macOS:

```sh
chmod +x gradlew scripts/build.sh scripts/verify-build.sh
./gradlew clean test build
./scripts/verify-build.sh
```

Windows PowerShell:

```powershell
.\gradlew.bat clean test build
.\scripts\build.bat
```

Installable JAR expected at `build/libs/worstoptimazation-1.0.0.jar`. Loom may also create a development JAR with a classifier; install only the remapped JAR without `-dev` in its name.

## GitHub Actions

Upload the source project into a GitHub repository and push to its default branch. The workflow at `.github/workflows/build.yml` installs Gradle 9.4.0, generates the canonical Gradle Wrapper files on the runner, uses that wrapper to build and test the real source, verifies the JAR contains `fabric.mod.json` and the client entrypoint, then uploads it as `worstoptimazation-1.0.0-jar`. It also uploads a `gradle-wrapper-9.4.0` artifact with the generated official wrapper files.

No API keys are required. This project does not use AI or a remote service.
