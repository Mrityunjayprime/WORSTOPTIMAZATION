package com.worstoptimazation.performance;

import java.util.Arrays;

/** Small fixed-size frame-time ring; no per-frame heap allocations. Called on the render thread. */
public final class FrameTimeMonitor {
    private final long[] frameTimes = new long[240];
    private int next;
    private int count;
    private long lastFrameNanos = -1L;
    private long lastSampleWindowNanos = -1L;
    private double currentFps = Double.NaN;

    public void recordFrameNanos(long nowNanos) {
        if (lastFrameNanos >= 0L && nowNanos > lastFrameNanos) {
            long delta = nowNanos - lastFrameNanos;
            frameTimes[next] = delta;
            next = (next + 1) % frameTimes.length;
            count = Math.min(count + 1, frameTimes.length);
            currentFps = 1_000_000_000.0 / delta;
            lastSampleWindowNanos = nowNanos;
        }
        lastFrameNanos = nowNanos;
    }

    public PerformanceStatistics snapshot() {
        if (count == 0) return PerformanceStatistics.unavailable();
        long[] samples = copySamples();
        long sum = 0L;
        long max = 0L;
        for (long sample : samples) {
            sum += sample;
            max = Math.max(max, sample);
        }
        if (sum <= 0L) return PerformanceStatistics.unavailable();
        double averageFps = samples.length * 1_000_000_000.0 / sum;
        double frameTimeMs = samples[samples.length - 1] / 1_000_000.0;
        long[] sorted = samples.clone();
        Arrays.sort(sorted);
        int p99Index = Math.min(sorted.length - 1, Math.max(0, (int) Math.ceil(sorted.length * 0.99) - 1));
        long p99 = sorted[p99Index];
        double onePercentLow = p99 > 0L ? 1_000_000_000.0 / p99 : Double.NaN;
        return new PerformanceStatistics(currentFps, averageFps, frameTimeMs, onePercentLow, count);
    }

    public int sampleCount() { return count; }

    private long[] copySamples() {
        long[] result = new long[count];
        int start = (next - count + frameTimes.length) % frameTimes.length;
        for (int i = 0; i < count; i++) result[i] = frameTimes[(start + i) % frameTimes.length];
        return result;
    }
}
