package com.worstoptimazation.performance;

public final class FpsMonitor {
    private static final FrameTimeMonitor MONITOR = new FrameTimeMonitor();

    private FpsMonitor() { }

    public static void recordFrame(long nowNanos) {
        MONITOR.recordFrameNanos(nowNanos);
    }

    public static PerformanceStatistics statistics() {
        return MONITOR.snapshot();
    }
}
