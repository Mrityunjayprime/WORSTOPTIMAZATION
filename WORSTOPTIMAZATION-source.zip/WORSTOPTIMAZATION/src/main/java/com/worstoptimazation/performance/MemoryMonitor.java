package com.worstoptimazation.performance;

public final class MemoryMonitor {
    private MemoryMonitor() { }

    public static MemoryStatistics snapshot() {
        Runtime runtime = Runtime.getRuntime();
        long committed = runtime.totalMemory();
        long freeWithinCommitted = runtime.freeMemory();
        long used = Math.max(0L, committed - freeWithinCommitted);
        long max = runtime.maxMemory();
        return new MemoryStatistics(used, committed, max);
    }

    public record MemoryStatistics(long usedBytes, long committedBytes, long maxHeapBytes) {
        public long usedMiB() { return usedBytes / (1024L * 1024L); }
        public long committedMiB() { return committedBytes / (1024L * 1024L); }
        public long maxHeapMiB() { return maxHeapBytes == Long.MAX_VALUE ? Long.MAX_VALUE : maxHeapBytes / (1024L * 1024L); }
    }
}
