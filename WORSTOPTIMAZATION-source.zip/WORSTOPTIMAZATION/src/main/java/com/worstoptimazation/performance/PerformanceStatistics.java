package com.worstoptimazation.performance;

public record PerformanceStatistics(double currentFps, double averageFps, double frameTimeMs,
                                    double onePercentLowFps, int sampleCount) {
    public static PerformanceStatistics unavailable() {
        return new PerformanceStatistics(Double.NaN, Double.NaN, Double.NaN, Double.NaN, 0);
    }
}
