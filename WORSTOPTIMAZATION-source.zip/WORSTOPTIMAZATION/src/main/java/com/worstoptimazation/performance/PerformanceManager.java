package com.worstoptimazation.performance;

public final class PerformanceManager {
    private PerformanceManager() { }

    public static PerformanceStatistics snapshot() {
        return FpsMonitor.statistics();
    }
}
