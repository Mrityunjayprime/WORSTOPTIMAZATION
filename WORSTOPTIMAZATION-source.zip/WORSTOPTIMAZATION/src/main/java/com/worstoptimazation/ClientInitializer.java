package com.worstoptimazation;

import com.mojang.blaze3d.platform.InputConstants;
import com.worstoptimazation.compatibility.CompatibilityChecker;
import com.worstoptimazation.config.ConfigManager;
import com.worstoptimazation.config.ModConfig;
import com.worstoptimazation.overlay.OverlayManager;
import com.worstoptimazation.performance.FpsMonitor;
import com.worstoptimazation.ui.OptimizationScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class ClientInitializer implements ClientModInitializer {
    private static KeyMapping openSettingsKey;
    private static KeyMapping toggleOverlayKey;

    @Override
    public void onInitializeClient() {
        WorstOptimazation.onClientInitialize();
        ConfigManager.load();
        CompatibilityChecker.refresh();

        openSettingsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.worstoptimazation.open", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_O, KeyMapping.Category.MISC));
        toggleOverlayKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.worstoptimazation.overlay", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_F8, KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openSettingsKey.consumeClick()) {
                client.setScreen(new OptimizationScreen(client.screen));
            }
            while (toggleOverlayKey.consumeClick()) {
                ModConfig config = ConfigManager.get();
                config.fpsOverlayEnabled = !config.fpsOverlayEnabled;
                ConfigManager.save();
            }
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(ModConstants.MOD_ID, "fps_overlay"),
                (graphics, tickCounter) -> {
                    FpsMonitor.recordFrame(System.nanoTime());
                    OverlayManager.render(graphics);
                });

        WorstOptimazation.LOGGER.info("Controls registered: O opens settings; F8 toggles the FPS overlay.");
    }
}
