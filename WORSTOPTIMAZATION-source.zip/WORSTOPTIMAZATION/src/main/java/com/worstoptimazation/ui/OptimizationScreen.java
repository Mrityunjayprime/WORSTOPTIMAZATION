package com.worstoptimazation.ui;

import com.worstoptimazation.compatibility.CompatibilityChecker;
import com.worstoptimazation.config.ConfigManager;
import com.worstoptimazation.config.ModConfig;
import com.worstoptimazation.optimization.OptimizationProfile;
import com.worstoptimazation.optimization.QuickOptimize;
import com.worstoptimazation.performance.FpsMonitor;
import com.worstoptimazation.performance.PerformanceStatistics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class OptimizationScreen extends Screen {
    private final Screen parent;

    public OptimizationScreen(Screen parent) {
        super(Component.literal("WORSTOPTIMAZATION"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int margin = 10;
        int gap = 4;
        int colW = Math.max(70, (this.width - margin * 2 - gap) / 2);
        int leftX = (this.width - (colW * 2 + gap)) / 2;
        int rightX = leftX + colW + gap;
        int rowY = Math.max(34, Math.min(42, this.height - 158));
        int rowGap = 22;
        ModConfig config = ConfigManager.get();

        addButton(leftX, rowY, colW, label("FPS Overlay: " + (config.fpsOverlayEnabled ? "ON" : "OFF")), b -> {
            config.fpsOverlayEnabled = !config.fpsOverlayEnabled; ConfigManager.save(); refresh();
        });
        addButton(rightX, rowY, colW, label("Particles: " + Minecraft.getInstance().options.particles().get().name()), b -> {
            ParticleStatus current = Minecraft.getInstance().options.particles().get();
            ParticleStatus next = current == ParticleStatus.ALL ? ParticleStatus.DECREASED
                    : current == ParticleStatus.DECREASED ? ParticleStatus.MINIMAL : ParticleStatus.ALL;
            Minecraft.getInstance().options.particles().set(next); Minecraft.getInstance().options.save(); markCustom(); refresh();
        });

        rowY += rowGap;
        addButton(leftX, rowY, colW, label("HUD Position: " + config.overlayPosition.replace('_', ' ')), b -> {
            String[] positions = {"TOP_LEFT", "TOP_RIGHT", "BOTTOM_RIGHT", "BOTTOM_LEFT"};
            int i = 0; for (int n = 0; n < positions.length; n++) if (positions[n].equals(config.overlayPosition)) i = n;
            config.overlayPosition = positions[(i + 1) % positions.length]; ConfigManager.save(); refresh();
        });
        addButton(rightX, rowY, colW, label("HUD Scale: " + String.format("%.2f", config.overlayScale)), b -> {
            config.overlayScale = config.overlayScale >= 1.49f ? 0.75f : config.overlayScale + 0.25f;
            ConfigManager.save(); refresh();
        });

        rowY += rowGap;
        addButton(leftX, rowY, colW, label("Render Distance −"), b -> adjustRenderDistance(-2));
        addButton(rightX, rowY, colW, label("Render Distance +"), b -> adjustRenderDistance(2));
        rowY += rowGap;
        addButton(leftX, rowY, colW, label("Simulation Distance −"), b -> adjustSimulationDistance(-1));
        addButton(rightX, rowY, colW, label("Simulation Distance +"), b -> adjustSimulationDistance(1));

        rowY += rowGap;
        int profileGap = 3;
        int profileW = (this.width - margin * 2 - profileGap * 3) / 4;
        int profileX = margin;
        addButton(profileX, rowY, profileW, label("LOW"), b -> openConfirmation(OptimizationProfile.LOW_END));
        addButton(profileX + profileW + profileGap, rowY, profileW, label("BALANCED"), b -> openConfirmation(OptimizationProfile.BALANCED));
        addButton(profileX + (profileW + profileGap) * 2, rowY, profileW, label("HIGH FPS"), b -> openConfirmation(OptimizationProfile.HIGH_FPS));
        addButton(profileX + (profileW + profileGap) * 3, rowY, profileW, label("CUSTOM"), b -> {
            ConfigManager.get().optimizationProfile = "CUSTOM"; ConfigManager.save(); refresh();
        });

        rowY += rowGap;
        addButton(leftX, rowY, colW, label("Restore Previous"), b -> {
            boolean restored = QuickOptimize.restore(Minecraft.getInstance());
            refresh();
        }).active = QuickOptimize.hasBackup();
        addButton(rightX, rowY, colW, label("Compatibility"), b -> Minecraft.getInstance().setScreen(new CompatibilityScreen(this)));

        rowY += rowGap;
        addButton(leftX, rowY, colW * 2 + gap, label("Save & Close"), b -> {
            ConfigManager.save(); Minecraft.getInstance().options.save(); Minecraft.getInstance().setScreen(parent);
        });
    }

    private void adjustRenderDistance(int amount) {
        var option = Minecraft.getInstance().options.renderDistance();
        option.set(Math.max(2, Math.min(32, option.get() + amount)));
        Minecraft.getInstance().options.save(); markCustom(); refresh();
    }

    private void adjustSimulationDistance(int amount) {
        var option = Minecraft.getInstance().options.simulationDistance();
        option.set(Math.max(5, Math.min(32, option.get() + amount)));
        Minecraft.getInstance().options.save(); markCustom(); refresh();
    }

    private void openConfirmation(OptimizationProfile profile) {
        Minecraft.getInstance().setScreen(new QuickOptimizeConfirmScreen(this, profile));
    }

    private void markCustom() {
        ConfigManager.get().optimizationProfile = "CUSTOM";
        ConfigManager.save();
    }

    private void refresh() { Minecraft.getInstance().setScreen(new OptimizationScreen(parent)); }
    private static Component label(String value) { return Component.literal(value); }
    private Button addButton(int x, int y, int width, Component text, java.util.function.Consumer<Button> action) {
        return this.addRenderableWidget(Button.builder(text, button -> action.accept(button)).bounds(x, y, width, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, Component.literal("WORSTOPTIMAZATION  •  " + ConfigManager.get().optimizationProfile + " PROFILE"), this.width / 2, 9, 0xFFE4D5FF);
        PerformanceStatistics stats = FpsMonitor.statistics();
        String status = Double.isFinite(stats.currentFps())
                ? String.format("FPS %.0f  |  Avg %.0f  |  Frame %.2f ms", stats.currentFps(), stats.averageFps(), stats.frameTimeMs())
                : "FPS samples are being collected…";
        graphics.drawCenteredString(this.font, Component.literal(status), this.width / 2, 22, 0xFFD6D1E2);
        if (this.height > 230) {
            graphics.drawCenteredString(this.font, Component.literal("Animation control: individual safe hooks are not provided in 1.0.0."), this.width / 2, this.height - 12, 0xFFAAA4BC);
        }
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0xF0101018);
        graphics.fill(0, 0, this.width, 2, 0xFF9B6DFF);
        graphics.fill(0, 30, this.width, 31, 0xFF4A365E);
    }

    @Override
    public void onClose() {
        ConfigManager.save();
        Minecraft.getInstance().setScreen(parent);
    }
}
