package com.worstoptimazation.ui;

import com.worstoptimazation.optimization.OptimizationProfile;
import com.worstoptimazation.optimization.QuickOptimize;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class QuickOptimizeConfirmScreen extends Screen {
    private final Screen parent;
    private final OptimizationProfile profile;

    public QuickOptimizeConfirmScreen(Screen parent, OptimizationProfile profile) {
        super(Component.literal("Confirm optimization"));
        this.parent = parent;
        this.profile = profile;
    }

    @Override
    protected void init() {
        int width = Math.min(150, (this.width - 28) / 2);
        int gap = 8;
        int left = (this.width - (width * 2 + gap)) / 2;
        int y = Math.min(this.height - 32, Math.max(120, this.height - 48));
        this.addRenderableWidget(Button.builder(Component.literal("Apply preset"), button -> {
            QuickOptimize.apply(Minecraft.getInstance(), profile);
            Minecraft.getInstance().setScreen(parent);
        }).bounds(left, y, width, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Cancel"), button -> Minecraft.getInstance().setScreen(parent))
                .bounds(left + width + gap, y, width, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, Component.literal("Apply " + profile.displayName() + " preset?"), this.width / 2, 28, 0xFFE4D5FF);
        graphics.drawCenteredString(this.font, Component.literal("A restore point will be saved before changes."), this.width / 2, 48, 0xFFDBD6E8);
        graphics.drawCenteredString(this.font, Component.literal("Only supported vanilla video options are changed."), this.width / 2, 63, 0xFFB8B2C9);
        String[] changes = QuickOptimize.plannedChanges(profile, Minecraft.getInstance());
        for (int i = 0; i < changes.length; i++) {
            graphics.drawCenteredString(this.font, Component.literal(changes[i]), this.width / 2, 88 + i * 15, 0xFFE9E4F4);
        }
        if (this.height > 230) graphics.drawCenteredString(this.font, Component.literal("No JVM arguments, world data, or server settings are modified."), this.width / 2, this.height - 15, 0xFFAAA4BC);
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0xF0101018);
        graphics.fill(0, 0, this.width, 2, 0xFF9B6DFF);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
