package com.worstoptimazation.ui;

import com.worstoptimazation.ModConstants;
import com.worstoptimazation.compatibility.CompatibilityChecker;
import com.worstoptimazation.compatibility.CompatibilityReport;
import com.worstoptimazation.config.ConfigManager;
import com.worstoptimazation.WorstOptimazation;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class CompatibilityScreen extends Screen {
    private final Screen parent;
    private String exportStatus = "";

    public CompatibilityScreen(Screen parent) {
        super(Component.literal("Compatibility Status"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = Math.min(140, (this.width - 24) / 2);
        int gap = 8;
        int x = (this.width - (w * 2 + gap)) / 2;
        int y = this.height - 32;
        addRenderableWidget(Button.builder(Component.literal("Export Report"), b -> exportReport()).bounds(x, y, w, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> Minecraft.getInstance().setScreen(parent))
                .bounds(x + w + gap, y, w, 20).build());
    }

    private void exportReport() {
        CompatibilityReport report = CompatibilityChecker.report();
        String content = "WORSTOPTIMAZATION diagnostic report\n"
                + "Mod version: " + ModConstants.VERSION + "\n"
                + "Minecraft: " + report.minecraftVersion() + "\n"
                + "Fabric Loader: " + report.fabricLoaderVersion() + "\n"
                + "Fabric API: " + report.fabricApiVersion() + "\n"
                + "Sodium: " + report.sodiumVersion() + "\n"
                + "BadOptimizations: " + report.badOptimizationsVersion() + "\n"
                + "Java: " + System.getProperty("java.version") + "\n";
        Path path = ConfigManager.configPath().resolveSibling("worstoptimazation-diagnostics.txt");
        try {
            Files.writeString(path, content, StandardCharsets.UTF_8);
            exportStatus = "Saved: " + path.getFileName();
        } catch (IOException e) {
            exportStatus = "Export failed; see latest.log.";
            WorstOptimazation.LOGGER.error("Diagnostic export failed", e);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        CompatibilityReport r = CompatibilityChecker.report();
        int y = 24;
        String[] rows = {
                "WORSTOPTIMAZATION: " + ModConstants.VERSION,
                "Minecraft target: " + r.minecraftVersion(),
                "Java runtime: " + System.getProperty("java.version"),
                "Fabric Loader: " + r.fabricLoaderVersion(),
                "Fabric API: " + r.fabricApiVersion(),
                "Sodium: " + r.sodiumVersion(),
                "BadOptimizations: " + r.badOptimizationsVersion(),
                "Sodium / BadOptimizations are optional and are not bundled.",
                "Missing optimization mods are reported, not treated as a crash."
        };
        for (String row : rows) {
            g.drawCenteredString(this.font, Component.literal(row), this.width / 2, y, 0xFFE4DFF0);
            y += 18;
        }
        if (!exportStatus.isBlank()) g.drawCenteredString(this.font, Component.literal(exportStatus), this.width / 2, this.height - 48, 0xFFBDA1FF);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, this.width, this.height, 0xF0101018);
        g.fill(0, 0, this.width, 2, 0xFF9B6DFF);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
