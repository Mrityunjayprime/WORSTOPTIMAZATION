package com.worstoptimazation.optimization;

import com.worstoptimazation.config.ConfigManager;
import com.worstoptimazation.config.ConfigPresets;
import com.worstoptimazation.config.ModConfig;
import com.worstoptimazation.WorstOptimazation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.Options;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Applies only vanilla options whose effects are directly exposed by the 1.21.11 client API. */
public final class QuickOptimize {
    private static final Path BACKUP_PATH = ConfigManager.configPath().resolveSibling("worstoptimazation-previous-settings.json");

    private QuickOptimize() { }

    public static String[] plannedChanges(OptimizationProfile profile, Minecraft client) {
        if (profile == OptimizationProfile.CUSTOM) return new String[] {"Custom profile: no automatic changes will be made."};
        return new String[] {
                "Render distance: " + client.options.renderDistance().get() + " -> " + profile.renderDistance() + " chunks",
                "Simulation distance: " + client.options.simulationDistance().get() + " -> " + profile.simulationDistance() + " chunks",
                "Global particles: " + client.options.particles().get().name() + " -> " + profile.particleStatus()
        };
    }

    public static boolean hasBackup() {
        return Files.isRegularFile(BACKUP_PATH);
    }

    public static void apply(Minecraft client, OptimizationProfile profile) {
        if (profile == OptimizationProfile.CUSTOM) return;
        Options options = client.options;
        ModConfig previousConfig = ConfigManager.get().copy();
        Snapshot snapshot = new Snapshot(options.renderDistance().get(), options.simulationDistance().get(),
                options.particles().get().name(), previousConfig);
        try {
            ConfigManager.writeObject(BACKUP_PATH, snapshot, false);
        } catch (IOException e) {
            WorstOptimazation.LOGGER.error("Could not save a restore point. Preset was not applied.", e);
            return;
        }

        options.renderDistance().set(Math.max(2, Math.min(32, profile.renderDistance())));
        options.simulationDistance().set(Math.max(5, Math.min(32, profile.simulationDistance())));
        try {
            options.particles().set(ParticleStatus.valueOf(profile.particleStatus()));
        } catch (IllegalArgumentException ignored) {
            // A malformed target value should never prevent the remaining supported option changes.
        }
        ConfigManager.get().optimizationProfile = profile.name();
        ConfigManager.save();
        options.save();
    }

    public static boolean restore(Minecraft client) {
        if (!hasBackup()) return false;
        try {
            Snapshot snapshot = ConfigManager.readObject(BACKUP_PATH, Snapshot.class);
            if (snapshot == null) return false;
            client.options.renderDistance().set(Math.max(2, Math.min(32, snapshot.renderDistance)));
            client.options.simulationDistance().set(Math.max(5, Math.min(32, snapshot.simulationDistance)));
            try { client.options.particles().set(ParticleStatus.valueOf(snapshot.particleStatus)); }
            catch (IllegalArgumentException ignored) { }
            if (snapshot.config != null) {
                ModConfig cfg = ConfigPresets.applyOverlayDefaults(snapshot.config, snapshot.config.optimizationProfile);
                copyInto(cfg, ConfigManager.get());
                ConfigManager.save();
            }
            client.options.save();
            return true;
        } catch (Exception e) {
            WorstOptimazation.LOGGER.error("Could not restore previous settings", e);
            return false;
        }
    }

    private static void copyInto(ModConfig src, ModConfig dst) {
        dst.configVersion = src.configVersion;
        dst.fpsOverlayEnabled = src.fpsOverlayEnabled;
        dst.showAverageFps = src.showAverageFps;
        dst.showFrameTime = src.showFrameTime;
        dst.showOnePercentLow = src.showOnePercentLow;
        dst.overlayPosition = src.overlayPosition;
        dst.overlayScale = src.overlayScale;
        dst.optimizationProfile = src.optimizationProfile;
    }

    private static final class Snapshot {
        int renderDistance;
        int simulationDistance;
        String particleStatus;
        ModConfig config;

        Snapshot() { }
        Snapshot(int renderDistance, int simulationDistance, String particleStatus, ModConfig config) {
            this.renderDistance = renderDistance;
            this.simulationDistance = simulationDistance;
            this.particleStatus = particleStatus;
            this.config = config;
        }
    }
}
