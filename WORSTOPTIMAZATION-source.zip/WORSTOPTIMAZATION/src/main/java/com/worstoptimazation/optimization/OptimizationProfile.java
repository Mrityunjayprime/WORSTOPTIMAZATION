package com.worstoptimazation.optimization;

public enum OptimizationProfile {
    LOW_END("Low-End", 5, 5, "MINIMAL"),
    BALANCED("Balanced", 10, 8, "DECREASED"),
    HIGH_FPS("High FPS", 6, 5, "MINIMAL"),
    CUSTOM("Custom", -1, -1, "UNCHANGED");

    private final String displayName;
    private final int renderDistance;
    private final int simulationDistance;
    private final String particleStatus;

    OptimizationProfile(String displayName, int renderDistance, int simulationDistance, String particleStatus) {
        this.displayName = displayName;
        this.renderDistance = renderDistance;
        this.simulationDistance = simulationDistance;
        this.particleStatus = particleStatus;
    }

    public String displayName() { return displayName; }
    public int renderDistance() { return renderDistance; }
    public int simulationDistance() { return simulationDistance; }
    public String particleStatus() { return particleStatus; }
}
