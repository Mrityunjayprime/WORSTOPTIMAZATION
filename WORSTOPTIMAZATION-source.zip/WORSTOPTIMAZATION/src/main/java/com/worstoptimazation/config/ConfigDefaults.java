package com.worstoptimazation.config;

public final class ConfigDefaults {
    private ConfigDefaults() {
    }

    public static ModConfig create() {
        return new ModConfig();
    }
}
