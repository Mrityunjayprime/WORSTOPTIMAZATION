package com.worstoptimazation.config;

import java.util.Locale;
import java.util.Set;

public final class ConfigValidator {
    private static final Set<String> POSITIONS = Set.of("TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT");
    private static final Set<String> PROFILES = Set.of("LOW_END", "BALANCED", "HIGH_FPS", "CUSTOM");

    private ConfigValidator() {
    }

    public static ModConfig validate(ModConfig config) {
        if (config == null) {
            config = ConfigDefaults.create();
        }
        config.configVersion = ConfigMigration.CURRENT_VERSION;
        if (config.overlayPosition == null || !POSITIONS.contains(config.overlayPosition.toUpperCase(Locale.ROOT))) {
            config.overlayPosition = "TOP_LEFT";
        } else {
            config.overlayPosition = config.overlayPosition.toUpperCase(Locale.ROOT);
        }
        if (!Float.isFinite(config.overlayScale)) {
            config.overlayScale = 1.0f;
        }
        config.overlayScale = Math.max(0.75f, Math.min(1.5f, config.overlayScale));
        if (config.optimizationProfile == null || !PROFILES.contains(config.optimizationProfile.toUpperCase(Locale.ROOT))) {
            config.optimizationProfile = "BALANCED";
        } else {
            config.optimizationProfile = config.optimizationProfile.toUpperCase(Locale.ROOT);
        }
        return config;
    }
}
