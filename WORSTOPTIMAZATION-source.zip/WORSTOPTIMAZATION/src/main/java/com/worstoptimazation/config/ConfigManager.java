package com.worstoptimazation.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.worstoptimazation.ModConstants;
import com.worstoptimazation.WorstOptimazation;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("worstoptimazation.json");
    private static ModConfig current = ConfigDefaults.create();

    private ConfigManager() {
    }

    public static synchronized void load() {
        if (!Files.exists(CONFIG_PATH)) {
            current = ConfigDefaults.create();
            save();
            return;
        }
        try {
            JsonObject raw = JsonParser.parseString(Files.readString(CONFIG_PATH, StandardCharsets.UTF_8)).getAsJsonObject();
            current = ConfigMigration.migrate(raw);
            save();
        } catch (Exception exception) {
            Path corrupt = CONFIG_PATH.resolveSibling("worstoptimazation.corrupt-" + System.currentTimeMillis() + ".json");
            try { Files.copy(CONFIG_PATH, corrupt, StandardCopyOption.COPY_ATTRIBUTES); }
            catch (IOException copyError) { WorstOptimazation.LOGGER.warn("Could not preserve malformed config at {}", CONFIG_PATH, copyError); }
            current = ConfigDefaults.create();
            WorstOptimazation.LOGGER.warn("Invalid WORSTOPTIMAZATION configuration; defaults loaded. Preserved bad file when possible.", exception);
            save();
        }
    }

    public static synchronized ModConfig get() {
        if (current == null) current = ConfigDefaults.create();
        return current;
    }

    public static synchronized void save() {
        current = ConfigValidator.validate(current);
        try {
            writeJsonFile(CONFIG_PATH, GSON.toJson(current), true);
        } catch (IOException exception) {
            WorstOptimazation.LOGGER.error("Failed to save configuration to {}", CONFIG_PATH, exception);
        }
    }

    public static Path configPath() { return CONFIG_PATH; }
    public static Gson gson() { return GSON; }

    public static void writeObject(Path path, Object value, boolean backupExisting) throws IOException {
        writeJsonFile(path, GSON.toJson(value), backupExisting);
    }

    public static <T> T readObject(Path path, Class<T> type) throws IOException {
        return GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), type);
    }

    public static void writeJsonFile(Path path, String content, boolean backupExisting) throws IOException {
        Files.createDirectories(path.getParent());
        if (backupExisting && Files.exists(path)) {
            Path backup = path.resolveSibling(path.getFileName() + ".bak");
            Files.copy(path, backup, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
        }
        Path temporary = path.resolveSibling(path.getFileName() + ".tmp");
        Files.writeString(temporary, content + System.lineSeparator(), StandardCharsets.UTF_8);
        try {
            Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
