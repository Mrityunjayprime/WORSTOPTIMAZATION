package com.worstoptimazation.config;

import java.util.Locale;

public final class ConfigPresets {
    private ConfigPresets() { }

    public static ModConfig applyOverlayDefaults(ModConfig source, String profile) {
        ModConfig result = (source == null ? ConfigDefaults.create() : source.copy());
        String p = profile == null ? "BALANCED" : profile.toUpperCase(Locale.ROOT);
        result.optimizationProfile = switch (p) {
            case "LOW_END" -> "LOW_END";
            case "HIGH_FPS" -> "HIGH_FPS";
            case "CUSTOM" -> "CUSTOM";
            default -> "BALANCED";
        };
        return ConfigValidator.validate(result);
    }
}
