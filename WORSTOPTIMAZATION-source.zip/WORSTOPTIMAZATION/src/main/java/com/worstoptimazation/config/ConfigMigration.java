package com.worstoptimazation.config;

import com.google.gson.JsonObject;

public final class ConfigMigration {
    public static final int CURRENT_VERSION = 1;

    private ConfigMigration() {
    }

    public static ModConfig migrate(JsonObject json) {
        if (json == null) return ConfigDefaults.create();
        int version = json.has("configVersion") && json.get("configVersion").isJsonPrimitive()
                ? safeInt(json.get("configVersion").getAsString(), 0) : 0;
        ModConfig result = ConfigDefaults.create();
        // v0 was the pre-versioned file. Gson's defaults fill missing fields safely.
        if (version <= CURRENT_VERSION) {
            try {
                result.fpsOverlayEnabled = getBoolean(json, "fpsOverlayEnabled", result.fpsOverlayEnabled);
                result.showAverageFps = getBoolean(json, "showAverageFps", result.showAverageFps);
                result.showFrameTime = getBoolean(json, "showFrameTime", result.showFrameTime);
                result.showOnePercentLow = getBoolean(json, "showOnePercentLow", result.showOnePercentLow);
                result.overlayPosition = getString(json, "overlayPosition", result.overlayPosition);
                result.overlayScale = getFloat(json, "overlayScale", result.overlayScale);
                result.optimizationProfile = getString(json, "optimizationProfile", result.optimizationProfile);
            } catch (RuntimeException ignored) {
                return ConfigDefaults.create();
            }
        }
        result.configVersion = CURRENT_VERSION;
        return ConfigValidator.validate(result);
    }

    private static boolean getBoolean(JsonObject o, String key, boolean fallback) {
        return o.has(key) && o.get(key).isJsonPrimitive() ? o.get(key).getAsBoolean() : fallback;
    }
    private static String getString(JsonObject o, String key, String fallback) {
        return o.has(key) && o.get(key).isJsonPrimitive() ? o.get(key).getAsString() : fallback;
    }
    private static float getFloat(JsonObject o, String key, float fallback) {
        return o.has(key) && o.get(key).isJsonPrimitive() ? o.get(key).getAsFloat() : fallback;
    }
    private static int safeInt(String text, int fallback) {
        try { return Integer.parseInt(text); } catch (NumberFormatException ignored) { return fallback; }
    }
}
