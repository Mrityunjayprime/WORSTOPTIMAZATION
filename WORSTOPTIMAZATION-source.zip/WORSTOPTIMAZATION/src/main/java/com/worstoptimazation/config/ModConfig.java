package com.worstoptimazation.config;

public final class ModConfig {
    public int configVersion = ConfigMigration.CURRENT_VERSION;
    public boolean fpsOverlayEnabled = true;
    public boolean showAverageFps = true;
    public boolean showFrameTime = true;
    public boolean showOnePercentLow = true;
    public String overlayPosition = "TOP_LEFT";
    public float overlayScale = 1.0f;
    public String optimizationProfile = "BALANCED";

    public ModConfig copy() {
        ModConfig copy = new ModConfig();
        copy.configVersion = configVersion;
        copy.fpsOverlayEnabled = fpsOverlayEnabled;
        copy.showAverageFps = showAverageFps;
        copy.showFrameTime = showFrameTime;
        copy.showOnePercentLow = showOnePercentLow;
        copy.overlayPosition = overlayPosition;
        copy.overlayScale = overlayScale;
        copy.optimizationProfile = optimizationProfile;
        return copy;
    }
}
