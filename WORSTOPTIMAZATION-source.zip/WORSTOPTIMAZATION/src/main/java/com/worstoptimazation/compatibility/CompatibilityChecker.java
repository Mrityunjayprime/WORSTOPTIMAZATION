package com.worstoptimazation.compatibility;

import com.worstoptimazation.ModConstants;
import net.fabricmc.loader.api.FabricLoader;

public final class CompatibilityChecker {
    private static volatile CompatibilityReport current = new CompatibilityReport(
            ModConstants.TARGET_MINECRAFT, "Unavailable", "Unavailable", "Not detected", "Not detected");

    private CompatibilityChecker() { }

    public static void refresh() {
        FabricLoader loader = FabricLoader.getInstance();
        current = new CompatibilityReport(
                ModConstants.TARGET_MINECRAFT,
                versionOf("fabricloader"),
                versionOf("fabric-api"),
                versionOf("sodium"),
                versionOf("badoptimizations"));
    }

    public static CompatibilityReport report() { return current; }

    public static String versionOf(String modId) {
        return FabricLoader.getInstance().getModContainer(modId)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("Not detected");
    }
}
