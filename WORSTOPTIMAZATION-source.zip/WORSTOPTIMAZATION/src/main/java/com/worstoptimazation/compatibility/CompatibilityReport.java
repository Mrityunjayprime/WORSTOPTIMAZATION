package com.worstoptimazation.compatibility;

public record CompatibilityReport(String minecraftVersion, String fabricLoaderVersion,
                                  String fabricApiVersion, String sodiumVersion,
                                  String badOptimizationsVersion) {
    public String sodiumStatus() { return "sodium".equals(sodiumVersion) ? "Detected; version unavailable" : sodiumVersion; }
    public String badOptimizationsStatus() { return "badoptimizations".equals(badOptimizationsVersion) ? "Detected; version unavailable" : badOptimizationsVersion; }
}
