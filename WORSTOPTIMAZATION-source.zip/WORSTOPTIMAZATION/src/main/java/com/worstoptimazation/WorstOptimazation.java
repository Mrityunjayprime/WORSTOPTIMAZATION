package com.worstoptimazation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class WorstOptimazation {
    public static final Logger LOGGER = LoggerFactory.getLogger(ModConstants.MOD_NAME);

    private WorstOptimazation() {
    }

    public static void onClientInitialize() {
        LOGGER.info("{} {} initialising for Minecraft {}", ModConstants.MOD_NAME,
                ModConstants.VERSION, ModConstants.TARGET_MINECRAFT);
    }
}
