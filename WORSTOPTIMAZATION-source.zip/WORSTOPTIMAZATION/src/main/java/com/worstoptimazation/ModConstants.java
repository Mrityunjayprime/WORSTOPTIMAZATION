package com.worstoptimazation;

public final class ModConstants {
    public static final String MOD_ID = "worstoptimazation";
    public static final String MOD_NAME = "WORSTOPTIMAZATION";
    public static final String VERSION = "1.0.0";
    public static final String TARGET_MINECRAFT = "1.21.11";

    private ModConstants() {
    }
}
