package com.worstoptimazation.overlay;

import com.worstoptimazation.config.ConfigManager;
import com.worstoptimazation.config.ModConfig;
import com.worstoptimazation.performance.FpsMonitor;
import com.worstoptimazation.performance.MemoryMonitor;
import com.worstoptimazation.performance.PerformanceStatistics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

public final class OverlayManager {
    private OverlayManager() { }

    public static void render(GuiGraphics graphics) {
        ModConfig config = ConfigManager.get();
        if (!config.fpsOverlayEnabled || Minecraft.getInstance().options.hideGui) return;
        PerformanceStatistics stats = FpsMonitor.statistics();
        MemoryMonitor.MemoryStatistics memory = MemoryMonitor.snapshot();
        String fps = Double.isFinite(stats.currentFps()) ? String.format("FPS %.0f", stats.currentFps()) : "FPS: measuring…";
        String line = fps;
        if (config.showAverageFps && Double.isFinite(stats.averageFps())) line += String.format("  AVG %.0f", stats.averageFps());
        if (config.showFrameTime && Double.isFinite(stats.frameTimeMs())) line += String.format("  %.2f ms", stats.frameTimeMs());
        if (config.showOnePercentLow && Double.isFinite(stats.onePercentLowFps())) line += String.format("  1%% low %.0f", stats.onePercentLowFps());
        String max = memory.maxHeapMiB() == Long.MAX_VALUE ? "unbounded" : Long.toString(memory.maxHeapMiB());
        String heap = String.format("JVM heap used %d / committed %d / max %s MiB", memory.usedMiB(), memory.committedMiB(), max);

        float scale = config.overlayScale;
        int textWidth = Math.max(Minecraft.getInstance().font.width(line), Minecraft.getInstance().font.width(heap));
        int scaledWidth = (int) Math.ceil((textWidth + 8) * scale);
        int scaledHeight = (int) Math.ceil(28 * scale);
        int x = switch (config.overlayPosition) {
            case "TOP_RIGHT", "BOTTOM_RIGHT" -> graphics.guiWidth() - scaledWidth - 4;
            default -> 4;
        };
        int y = switch (config.overlayPosition) {
            case "BOTTOM_LEFT", "BOTTOM_RIGHT" -> graphics.guiHeight() - scaledHeight - 4;
            default -> 4;
        };
        graphics.pose().pushPose();
        graphics.pose().translate(x, y, 0.0f);
        graphics.pose().scale(scale, scale, 1.0f);
        graphics.fill(0, 0, textWidth + 8, 28, 0xB5101018);
        graphics.drawString(Minecraft.getInstance().font, Component.literal(line), 4, 3, 0xFFE5D8FF, false);
        graphics.drawString(Minecraft.getInstance().font, Component.literal(heap), 4, 15, 0xFFC6C2D4, false);
        graphics.pose().popPose();
    }
}
