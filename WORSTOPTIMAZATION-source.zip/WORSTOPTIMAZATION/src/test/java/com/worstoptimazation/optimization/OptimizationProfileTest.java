package com.worstoptimazation.optimization;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OptimizationProfileTest {
    @Test void presetsExposeDistinctSupportedSettings() {
        assertEquals("MINIMAL", OptimizationProfile.LOW_END.particleStatus());
        assertEquals("DECREASED", OptimizationProfile.BALANCED.particleStatus());
        assertEquals("MINIMAL", OptimizationProfile.HIGH_FPS.particleStatus());
        assertTrue(OptimizationProfile.LOW_END.renderDistance() < OptimizationProfile.BALANCED.renderDistance());
        assertEquals(-1, OptimizationProfile.CUSTOM.renderDistance());
    }
}
