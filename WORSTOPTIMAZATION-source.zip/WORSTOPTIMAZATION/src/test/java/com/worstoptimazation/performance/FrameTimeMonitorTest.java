package com.worstoptimazation.performance;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FrameTimeMonitorTest {
    @Test void derivesFrameTimeAndFpsFromRealSampleTimestamps() {
        FrameTimeMonitor monitor = new FrameTimeMonitor();
        monitor.recordFrameNanos(1_000_000_000L);
        monitor.recordFrameNanos(1_016_666_667L);
        monitor.recordFrameNanos(1_033_333_334L);
        PerformanceStatistics stats = monitor.snapshot();
        assertEquals(60.0, stats.currentFps(), 0.01);
        assertEquals(60.0, stats.averageFps(), 0.01);
        assertEquals(16.666667, stats.frameTimeMs(), 0.01);
        assertEquals(60.0, stats.onePercentLowFps(), 0.1);
    }

    @Test void reportsUnavailableBeforeTwoFrames() {
        FrameTimeMonitor monitor = new FrameTimeMonitor();
        monitor.recordFrameNanos(10L);
        assertTrue(Double.isNaN(monitor.snapshot().currentFps()));
    }
}
