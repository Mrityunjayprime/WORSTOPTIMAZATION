package com.worstoptimazation.config;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ConfigValidatorTest {
    @Test void clampsScaleAndRepairsUnknownValues() {
        ModConfig config = new ModConfig();
        config.overlayScale = Float.POSITIVE_INFINITY;
        config.overlayPosition = "teleport";
        config.optimizationProfile = "turbo_999";
        ModConfig checked = ConfigValidator.validate(config);
        assertEquals(1.0f, checked.overlayScale);
        assertEquals("TOP_LEFT", checked.overlayPosition);
        assertEquals("BALANCED", checked.optimizationProfile);
        assertEquals(ConfigMigration.CURRENT_VERSION, checked.configVersion);
    }

    @Test void scaleStaysWithinSupportedBounds() {
        ModConfig config = new ModConfig();
        config.overlayScale = 99f;
        assertEquals(1.5f, ConfigValidator.validate(config).overlayScale);
        config.overlayScale = 0.1f;
        assertEquals(0.75f, ConfigValidator.validate(config).overlayScale);
    }
}
