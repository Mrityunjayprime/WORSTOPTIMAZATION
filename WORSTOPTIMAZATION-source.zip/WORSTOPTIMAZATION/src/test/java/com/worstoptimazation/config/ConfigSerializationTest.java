package com.worstoptimazation.config;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConfigSerializationTest {
    private final Gson gson = new Gson();

    @Test
    void configRoundTripsThroughJsonWithoutLosingSettings() {
        ModConfig original = new ModConfig();
        original.fpsOverlayEnabled = false;
        original.showAverageFps = false;
        original.overlayPosition = "BOTTOM_RIGHT";
        original.overlayScale = 1.25f;
        original.optimizationProfile = "HIGH_FPS";

        ModConfig restored = gson.fromJson(gson.toJson(original), ModConfig.class);
        assertNotNull(restored);
        assertFalse(restored.fpsOverlayEnabled);
        assertFalse(restored.showAverageFps);
        assertEquals("BOTTOM_RIGHT", restored.overlayPosition);
        assertEquals(1.25f, restored.overlayScale);
        assertEquals("HIGH_FPS", restored.optimizationProfile);
    }

    @Test
    void migrationAcceptsLegacyFilesAndRepairsInvalidValues() {
        var legacy = JsonParser.parseString("""
                {
                  "fpsOverlayEnabled": false,
                  "overlayPosition": "unknown",
                  "overlayScale": 50.0,
                  "optimizationProfile": "turbo"
                }
                """).getAsJsonObject();

        ModConfig migrated = ConfigMigration.migrate(legacy);
        assertFalse(migrated.fpsOverlayEnabled);
        assertEquals(ConfigMigration.CURRENT_VERSION, migrated.configVersion);
        assertEquals("TOP_LEFT", migrated.overlayPosition);
        assertEquals(1.5f, migrated.overlayScale);
        assertEquals("BALANCED", migrated.optimizationProfile);
    }
}
