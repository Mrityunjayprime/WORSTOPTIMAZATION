@echo off
setlocal
cd /d "%~dp0.."
call gradlew.bat clean test build
if errorlevel 1 exit /b %errorlevel%
