#!/usr/bin/env sh
set -eu
JAR="build/libs/worstoptimazation-1.0.0.jar"
[ -s "$JAR" ] || { echo "ERROR: expected JAR is missing or empty: $JAR" >&2; exit 1; }
jar tf "$JAR" | grep -q '^fabric.mod.json$' || { echo "ERROR: fabric.mod.json is missing" >&2; exit 1; }
jar tf "$JAR" | grep -q '^com/worstoptimazation/ClientInitializer.class$' || { echo "ERROR: ClientInitializer.class is missing" >&2; exit 1; }
echo "Verified $JAR"
